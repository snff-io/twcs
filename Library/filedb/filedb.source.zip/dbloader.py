import os
import re
from unidecode import unidecode

# Output root directory
output_root = "/srv/filedb/"

# Function to sanitize a string for use as a file/directory name
def sanitize_filename(name):
    # Replace any non-alphanumeric character with a plus sign
    sanitized_name = ''.join(c if c.isalnum() else '+' for c in name)
    # Remove leading and trailing plus signs
    sanitized_name = sanitized_name.strip('+')
    return sanitized_name


def safe_encode_filename(filename):
    # Define a regular expression pattern to match safe characters
    pattern = r'^[a-zA-Z0-9_.-]+$'
    
    # Check if the filename matches the pattern
    if re.match(pattern, filename):
        return filename
    else:
        # If the filename contains unsafe characters, replace them with underscores
        return re.sub(r'[^\w.-]', '-', filename)

# Function to determine the folder name for a given name
def get_folder_name(name):
    # Get the first character of the name
    first_char = name[0].lower()
    # Check if it's alphabetic
    if first_char.isalpha():
        return first_char  # Return the first character if it's alphabetic
    else:
        return "other"  # Return "other" if the first character is not alphabetic

# Loop through files matching the pattern "names_<type>"
for filename in os.listdir("."):
    # Check if the file name starts with "names_"
    if filename.startswith("names_"):
        # Extract the type from the filename
        type = filename.split("_")[1]
        type = type.replace(".txt", "")

        # Create directory for the type if it doesn't exist
        os.makedirs(os.path.join(output_root, type), exist_ok=True)
        count = 0
        # Read each line in the file
        with open(filename, "r", encoding="utf-8") as file:
            
            for line in file:

                line = unidecode(line)
                # Replace space with dash, comma with underscore, and / with dash
                formatted_line = line.strip().replace('_', "-") .replace(" ", "-").replace(",", "_").replace("/", "-")
                
    
                                # Extract first and last names
                first_name, last_name = formatted_line.split("_",)
                


                # Create YAML content
                yaml_content = f"Id: {formatted_line.lower()}\nFirstName: {first_name}\nLastName: {last_name}\nType: {type}"

                # Determine folder for sorting
                first_char = get_folder_name(first_name)
                folder = os.path.join(output_root, type, first_char)

                # Create directory if it doesn't exist
                os.makedirs(folder, exist_ok=True)

                count = count+1
                if count % 1000 == 0:
                    print(str(count))

                fnenc = safe_encode_filename(f"{first_name}_{last_name}.yaml").lower()
                # Write YAML content to file in the appropriate directory
                with open(os.path.join(folder, fnenc), "w", encoding="utf-8") as yaml_file:
                    yaml_file.write(yaml_content)
